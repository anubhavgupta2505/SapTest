import { MedsDetail } from './Meds-detail.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MedsDetailService {

  formData: MedsDetail = new MedsDetail();
  readonly rootURL = 'https://localhost:44333/api';
  list: MedsDetail[];

  constructor(private http: HttpClient) { }

  // tslint:disable-next-line: typedef
  postMedsDetail() {
    const reqHeader = new HttpHeaders().set('Content-Type', 'application/json')
    .set('Accept', 'application/json');
    return this.http.post(`${this.rootURL}/products`, this.formData, {headers : reqHeader});
  }
  // tslint:disable-next-line: typedef
  putMedsDetail() {
    return this.http.put(`${this.rootURL}/products/${this.formData.ID}`, this.formData);
  }
  // tslint:disable-next-line: typedef
  deleteMedsDetail(id) {
    console.log(id);
    return this.http.delete(`${this.rootURL}/products/${id}`);
  }
// tslint:disable-next-line: typedef
  refreshList() {
    this.http.get(`${this.rootURL}/products/`)
      .toPromise()
      .then(res => this.list = res as MedsDetail[]);
  }
}
