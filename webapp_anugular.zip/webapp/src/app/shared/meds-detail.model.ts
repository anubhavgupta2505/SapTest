export class MedsDetail {
    ID: String;
    FullName: string;
    Brand: string;
    Price: String;
    Quantity: String;
    Date: string;
    Notes: string;
}