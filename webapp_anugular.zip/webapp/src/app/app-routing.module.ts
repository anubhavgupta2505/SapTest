import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MedsDetailListComponent } from './meds-details/meds-details.component';
import { MedsDetailFormComponent } from './meds-details/meds-detail-form/meds-detail-form.component';

const routes: Routes = [
  { path:  '', redirectTo:  'MedsDetailListComponent', pathMatch:  'full' },
  {
    path: 'medlist',
    component: MedsDetailListComponent
  },
  {
    path: 'addmeds',
    component: MedsDetailFormComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

