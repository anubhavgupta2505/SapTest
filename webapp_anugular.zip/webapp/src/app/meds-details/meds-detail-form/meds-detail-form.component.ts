import { MedsDetailService } from './../../shared/meds-detail.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Component,  OnInit,Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-meds-detail-form',
  templateUrl: './meds-detail-form.component.html',
  styles: []
})
export class MedsDetailFormComponent implements OnInit {
  @Input() form: NgForm;
  @Output() changeName = new EventEmitter();

  // tslint:disable-next-line: typedef
  populateForm(form) {
    this.service.formData = Object.assign({}, form);
  }


  constructor(public service: MedsDetailService, private toastr: ToastrService, private router: Router) { }

  // tslint:disable-next-line: typedef
  ngOnInit() {
    this.resetForm();
  }
  // tslint:disable-next-line: typedef
  onSubmit(form: NgForm) {
    this.router.navigateByUrl('/medlist');
    // tslint:disable-next-line: triple-equals
    if (this.service.formData.ID == '0') {
      console.log(form.value);
      this.insertRecord(form);
    }
    else {
      this.updateRecord(form);
    }
  }
  // tslint:disable-next-line: typedef
  insertRecord(form: NgForm) {
       this.service.postMedsDetail().subscribe(
      res => {
        this.resetForm(form);
        this.service.refreshList();
      },
      err => { console.log(err); }
    );
  }

  // tslint:disable-next-line: typedef
  updateRecord(form: NgForm) {
    this.service.putMedsDetail().subscribe(
      res => {
        this.resetForm(form);
        this.toastr.info('Submitted successfully', 'Meds Detail Register');
        this.service.refreshList();
      },
      err => {
        console.log(err);
      }
    );
  }
  // tslint:disable-next-line: typedef
  resetForm(form?: NgForm) {
    if (form != null) {
      form.form.reset();
    }
    this.service.formData = {
      ID: '0',
      FullName: '',
      Brand: '',
      Price: '0',
      Quantity: '0',
      Date: '',
      Notes: ''
    };
  }
}
