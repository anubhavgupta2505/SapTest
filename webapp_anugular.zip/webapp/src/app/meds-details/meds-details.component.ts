import { MedsDetailService } from '../shared/meds-detail.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {POPOUT_MODAL_DATA, POPOUT_MODALS, PopoutData, PopoutModalName} from '../shared/popout.tokens';
import {PopoutService} from '../shared/popout.service';

@Component({
  selector: 'app-meds-details',
  templateUrl: './meds-details.component.html',
  styles: []
})
export class MedsDetailListComponent implements OnInit {

  constructor(public service: MedsDetailService, private router: Router,  private popoutService: PopoutService) { }

  // tslint:disable-next-line: typedef
  ngOnInit() {
    this.service.refreshList();
  }
  // tslint:disable-next-line: typedef
  // @HostListener('window:beforeunload', ['$event'])
  // // tslint:disable-next-line: typedef
  // onWindowClose(event: Event) {
  //   this.popoutService.closePopoutModal();
  // }
  // // tslint:disable-next-line: typedef
  // openMedicinePopout(ID: string) {
  //   const modalData = {
  //     modalName: PopoutModalName.medsDetail,
  //     FullName: name,
  //     id: this.medsDetails[name].id,
  //     age: this.medsDetails[name].age,
  //     employer: this.medsDetails[name].employer
  //   };

  //   const medsPopoutDetails = POPOUT_MODALS[PopoutModalName.medsDetail];

  //   if (!this.popoutService.isPopoutWindowOpen()) {
  //     this.popoutService.openPopoutModal(modalData);
  //   } else {
  //     const samemeds = POPOUT_MODALS['componentInstance'].name === name;
  //     // When popout modal is open and there is no change in data, focus on popout modal
  //     if (samemeds) {
  //       this.popoutService.focusPopoutWindow();
  //     } else {
  //       POPOUT_MODALS['outlet'].detach();
  //       const injector = this.popoutService.createInjector(modalData);
  //       const componentInstance = this.popoutService.attachmedsContainer(POPOUT_MODALS['outlet'], injector);
  //       POPOUT_MODALS['componentInstance'] = componentInstance;
  //       this.popoutService.focusPopoutWindow();
  //     }
  //   }
  // }
  // tslint:disable-next-line: typedef
  onDelete(ID) {
    if (confirm('Are you sure to delete this record ?')) {
      console.log(ID);
      this.service.deleteMedsDetail(ID)
        .subscribe(res => {
          this.service.refreshList();
        },
        err => { console.log(err); });
    }
  }
}
